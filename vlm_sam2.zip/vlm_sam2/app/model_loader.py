import os
from sam2.sam2_image_predictor import SAM2ImagePredictor
os.environ["CUDA_VISIBLE_DEVICES"] = "7"

def load_model():
    segmentation_model_path = "facebook/sam2-hiera-large"
    segmentation_model = SAM2ImagePredictor.from_pretrained(segmentation_model_path)
    return segmentation_model