# app/main.py
from pathlib import Path
import uvicorn
from fastapi import FastAPI, HTTPException
from app.schemas import InferenceRequest
from app.model_loader import load_model
from app.predictor import generate_masks_and_instance_ids
from fastapi.encoders import jsonable_encoder
from app.utils import save_coco_json,draw_instance_segmentation
import pdb




# RESULT_DIR = "/data2/vlm/wmx_code/vlm_sam2/imgoutputs"

sam_model = load_model()

app = FastAPI(title="Async SAM2 Segmentation Server")

@app.post("/segment")
async def segment(request: InferenceRequest):
    try:
        print(sam_model,
            request.image_path,
            request.points,
            request.bboxes,
            request.class_ids)
        mask_all, instance_id_map,id_to_label,image,img_height, img_width = generate_masks_and_instance_ids(
            sam_model,
            request.image_path,
            request.points,
            request.bboxes,
            request.class_ids
        )
        print(mask_all, instance_id_map,id_to_label)
        
        # pdb.set_trace()
        inp = Path(request.image_path)
        stem = inp.stem
        result_img_path = request.image_path.replace(".jpg","_result.jpg")
        result_json_path = request.image_path.replace(".jpg","_result.json")
        # result_img_path  = str(Path(RESULT_DIR) / f"{stem}_result{inp.suffix}")
        # result_json_path = str(Path(RESULT_DIR) / f"{stem}_result.json")
        save_coco_json(output_path=result_json_path,image_name=request.image_path,width=img_width,height=img_height,instance_id_map=instance_id_map,id_to_label=id_to_label)
        draw_instance_segmentation(image,instance_id_map,id_to_label,0.5,result_img_path)
        return True
        

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    uvicorn.run("app.main:app", host="0.0.0.0", port=7860)
