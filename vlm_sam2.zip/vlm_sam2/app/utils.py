import matplotlib.pyplot as plt
import numpy as np
import cv2
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
import random
from pycocotools import mask as mask_utils
import os
import json

def save_coco_json(output_path, image_name, width, height, instance_id_map, id_to_label):
    categories = []
    annotations = []
    image_id = 1
    ann_id = 1
    label2id = {}
    
    for instance_id, class_name in id_to_label.items():
        # pdb.set_trace()
        if class_name not in label2id:
            label2id[class_name] = len(label2id) + 1
            categories.append({"id": label2id[class_name], "name": class_name})
    
    for instance_id, class_name in id_to_label.items():
        mask = (instance_id_map == instance_id).astype(np.uint8)
        if mask.sum() == 0:
            continue
        encoded_mask = mask_utils.encode(np.asfortranarray(mask))
        area = float(mask_utils.area(encoded_mask))
        bbox = mask_utils.toBbox(encoded_mask).tolist()  # [x, y, w, h]

        annotations.append({
            "id": ann_id,
            "image_id": image_id,
            "category_id": label2id[class_name],
            "bbox": bbox,
            "area": area
        })
        ann_id += 1

    coco_format = {
        "images": [{
            "id": image_id,
            "file_name": os.path.basename(image_name),
            "width": width,
            "height": height
        }],
        "annotations": annotations,
        "categories": categories
    }

    with open(output_path, 'w') as f:
        json.dump(coco_format, f, indent=2, ensure_ascii=False)
    print(f"COCO annotations saved to {output_path}")

    npy_path = os.path.splitext(output_path)[0] + '.npy'
    np.save(npy_path, instance_id_map)
    print(f"instance_id_map saved to {npy_path}")







def visualize_results_enhanced(image, result, task_type, output_path):
    """
    Enhanced visualization with three-panel layout
    """
    plt.figure(figsize=(15, 5))
    
    plt.subplot(1, 3, 1)
    plt.imshow(image)
    plt.title('Original Image')
    plt.axis('off')
    
    plt.subplot(1, 3, 2)
    plt.imshow(image)
    
    if 'bboxes' in result and result['bboxes']:
        for bbox in result['bboxes']:
            x1, y1, x2, y2 = bbox
            rect = plt.Rectangle((x1, y1), x2-x1, y2-y1, 
                               fill=False, edgecolor='red', linewidth=2)
            plt.gca().add_patch(rect)
    
    if 'points' in result and result['points']:
        for point in result['points']:
            plt.plot(point[0], point[1], 'go', markersize=8)  
    
    plt.title('Image with Bounding Boxes')
    plt.axis('off')
    
    plt.subplot(1, 3, 3)
    plt.imshow(image, alpha=0.6)
    
    if task_type == 'segmentation' and 'masks' in result and result['masks'] is not None:
        mask = result['masks']
        if np.any(mask):
            mask_overlay = np.zeros_like(np.array(image))
            mask_overlay[mask] = [255, 0, 0]  
            plt.imshow(mask_overlay, alpha=0.4)
    
    if task_type == 'detection' or task_type == 'counting':
        if 'bboxes' in result and result['bboxes']:
            for bbox in result['bboxes']:
                x1, y1, x2, y2 = bbox
                rect = plt.Rectangle((x1, y1), x2-x1, y2-y1, 
                                 fill=True, edgecolor='red', facecolor='red', alpha=0.3)
                plt.gca().add_patch(rect)
    
    task_title = {
        'detection': 'Detection Overlay',
        'segmentation': 'Segmentation Mask',
        'counting': 'Counting Results',
        'qa': 'Visual QA'
    }
    
    plt.title(task_title.get(task_type, 'Results Overlay'))
    plt.axis('off')
    
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()

def draw_instance_segmentation(
    image: Image.Image,
    instance_id_map: np.ndarray,
    id_to_label: dict = None,
    alpha: float = 0.5,
    save_path: str = None
):
    image_np = np.array(image.convert("RGB")).copy()
    overlay = image_np.copy()

    unique_ids = np.unique(instance_id_map)
    unique_ids = unique_ids[unique_ids != 0]  

    font = cv2.FONT_HERSHEY_SIMPLEX

    for inst_id in unique_ids:
        mask = instance_id_map == inst_id

        if id_to_label and inst_id in id_to_label:
            label = id_to_label[inst_id]
            random.seed(hash(label) % (2**32))
        else:
            label = str(inst_id)
            random.seed(int(inst_id))

        color = [random.randint(50, 255) for _ in range(3)]

        overlay[mask] = (1 - alpha) * overlay[mask] + alpha * np.array(color)

        contours, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cv2.drawContours(overlay, contours, -1, tuple(int(c) for c in color), 2)

        ys, xs = np.where(mask)
        if len(xs) > 0:
            cx, cy = int(np.mean(xs)), int(np.mean(ys))
            text = f"{label}"
            cv2.putText(
                overlay, text, (cx - 10, cy),
                font, 0.6, (255, 255, 255), 2, lineType=cv2.LINE_AA
            )

    if save_path:
        cv2.imwrite(save_path, cv2.cvtColor(overlay.astype(np.uint8), cv2.COLOR_RGB2BGR))

    return overlay.astype(np.uint8)