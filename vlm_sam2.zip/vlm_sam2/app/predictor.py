from PIL import Image
import pdb
import numpy as np
import os
import re
import json
import base64


def generate_masks_and_instance_ids(segmentation_model,image_path, points,bboxes,class_ids):
    image = Image.open(image_path).convert("RGB")
    img_height, img_width = image.height, image.width
    mask_all = np.zeros((img_height, img_width), dtype=bool)
    instance_id_map = np.zeros((img_height, img_width), dtype=np.uint16)
    id_to_label = {}

    if not bboxes or (points and len(points) != len(bboxes)):
        return mask_all, instance_id_map,id_to_label

    try:
        segmentation_model.set_image(image)
        instance_id = 1

        if points:
            for bbox, point,class_id in zip(bboxes, points,class_ids):
                masks, scores, _ = segmentation_model.predict(
                    point_coords=[point],
                    point_labels=[1],
                    box=bbox
                )
                sorted_ind = np.argsort(scores)[::-1]
                mask = masks[sorted_ind[0]].astype(bool)
                mask_all = np.logical_or(mask_all, mask)
                instance_id_map[mask] = instance_id
                id_to_label[instance_id] = class_id
                instance_id += 1
                
        else:
            for bbox in bboxes:
                masks, scores, _ = segmentation_model.predict(box=bbox)
                sorted_ind = np.argsort(scores)[::-1]
                mask = masks[sorted_ind[0]].astype(bool)
                mask_all = np.logical_or(mask_all, mask)
                instance_id_map[mask] = instance_id
                id_to_label[instance_id] = class_id
                instance_id += 1
                

        return mask_all, instance_id_map,id_to_label,image,img_height, img_width
    except Exception as e:
        print(f"Error generating masks and instance IDs: {e}")
        return mask_all, instance_id_map,id_to_label