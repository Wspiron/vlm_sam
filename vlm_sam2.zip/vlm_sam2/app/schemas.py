from typing import List
from pydantic import BaseModel

class InferenceRequest(BaseModel):
    image_path: str
    points: List[List[int]] = []
    bboxes: List[List[int]] = []
    class_ids: List[str] = []
