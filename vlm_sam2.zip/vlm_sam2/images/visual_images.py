import matplotlib.pyplot as plt
import numpy as np
import numpy as np
from PIL import Image
import os
import json

img_arr = np.load("/data2/vlm/wmx_code/vlm_sam2/images/3_result.npy")
print(img_arr.shape)  


def generate_mask_images(npy_path, json_path, output_dir='/data2/vlm/wmx_code/vlm_sam2/images/mask_outputs'):
    """
    根据JSON中的类别信息生成每个物体的mask图片
    
    参数:
    npy_path -- 包含mask数据的.npy文件路径
    json_path -- 包含类别信息的JSON文件路径
    output_dir -- 输出目录 (默认: 'category_masks')
    """

    
    with open(json_path, 'r') as f:
        data = json.load(f)
        print(f"成功加载JSON数据：{json_path}")
    # 加载.npy文件
    mask_array = np.load(npy_path)
    print(f"成功加载mask数组: {npy_path}")
    print(f"数组形状: {mask_array.shape}")
    filename = data["images"][0]["file_name"].split('.')[0]
    print(filename)
    
    # 创建输出目录
    output_dir = os.path.join(output_dir,f"picture_{filename}")
    os.makedirs(output_dir, exist_ok=True)
    
    # 创建物体ID到类别名称的映射字典
    obj_id_to_category = {}
    for ann in data['annotations']:
        obj_id = ann['id']
        category_id = ann['category_id']
        
        # 查找类别名称
        category_name = next((cat['name'] for cat in data['categories'] if cat['id'] == category_id), None)
        
        if category_name:
            obj_id_to_category[obj_id] = category_name
        else:
            print(f"警告: 物体ID {obj_id} 的类别ID {category_id} 未找到对应的类别名称")


    # 获取所有物体编号（排除0）
    object_ids = np.unique(mask_array)
    object_ids = object_ids[object_ids != 0]
    
    print(f"发现 {len(object_ids)} 个物体")
    
    # 为每个物体创建mask图片
    for obj_id in object_ids:
        # 创建二值掩膜：目标物体为255，其它为0
        binary_mask = np.where(mask_array == obj_id, 255, 0).astype(np.uint8)
        
        category_name = obj_id_to_category[obj_id]
        safe_category = category_name.replace(' ', '_').replace('/', '_')
        # 创建PIL图像
        img = Image.fromarray(binary_mask)
        img_path = os.path.join(output_dir,f"{safe_category}_mask_{int(obj_id)}.png")
        # 保存图片
        img.save(img_path)
    
    print(f"所有掩膜图片已保存至 {output_dir} 目录")

if __name__ == "__main__":
    # 修改为你的.npy文件路径
    npy_npy_path = '/data2/vlm/wmx_code/vlm_sam2/images/3_result.npy'
    result_json_path = '/data2/vlm/wmx_code/vlm_sam2/images/3_result.json'
    generate_mask_images(npy_npy_path,result_json_path)