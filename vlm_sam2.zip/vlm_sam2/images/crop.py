import json
import os
from PIL import Image

# 1. 参数配置
JSON_PATH   = "/data2/vlm/wmx_code/vlm_sam2/images/cube__result.json"    # 你的 JSON 文件路径
IMAGE_DIR   = "/data2/vlm/wmx_code/vlm_sam2/images"              # 存放原图的文件夹
OUTPUT_DIR  = "/data2/vlm/wmx_code/vlm_sam2/images/crop_outputs"               # 裁剪结果输出目录

# 2. 加载 JSON
with open(JSON_PATH, "r", encoding="utf-8") as f:
    data = json.load(f)

# 3. 取出第一张图的信息
img_info = data["images"][0]
file_name = img_info["file_name"]      # e.g. "2.jpg"
file_name_prefix = os.path.splitext(file_name)[0]
outputdir = os.path.join(OUTPUT_DIR,str(file_name_prefix))
orig_w, orig_h = img_info["width"], img_info["height"]


# 5. 打开原图
img_path = os.path.join(IMAGE_DIR, file_name)
img = Image.open(img_path)

# 6. 创建输出目录
os.makedirs(outputdir, exist_ok=True)

# 创建物体ID到类别名称的映射字典
obj_id_to_category = {}
for ann in data['annotations']:
    obj_id = ann['id']
    category_id = ann['category_id']
    
    # 查找类别名称
    category_name = next((cat['name'] for cat in data['categories'] if cat['id'] == category_id), None)
    
    if category_name:
        obj_id_to_category[obj_id] = category_name
    else:
        print(f"警告: 物体ID {obj_id} 的类别ID {category_id} 未找到对应的类别名称")


# 7. 遍历每个 annotation，反向映射 bbox 并裁剪
for ann in data["annotations"]:
    x_min, y_min, w, h = ann["bbox"]
    # 反向缩放到原图坐标
    x0 = x_min 
    y0 = y_min 
    x1 = x_min + w
    y1 = y_min + h
    # x0 = int(x_min / 1000.0 * orig_w)
    # y0 = int(y_min / 1000.0 * orig_h)
    # x1 = int((x_min + w) / 1000.0 * orig_w)
    # y1 = int((y_min + h) / 1000.0 * orig_h)
    # 裁剪并保存
    crop = img.crop((x0, y0, x1, y1))
    category_name = obj_id_to_category[ann['id']]
    out_name = f"{os.path.splitext(file_name)[0]}_ann{ann['id']}_{category_name}.jpg"
    crop.save(os.path.join(outputdir, out_name))

    print(f"Saved crop for ann {ann['id']} → {outputdir}/{out_name}")
