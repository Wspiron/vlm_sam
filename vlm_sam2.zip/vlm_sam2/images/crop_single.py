"""
Crop objects from images according to COCO-style JSON.
Supports single-image and whole-folder processing.
"""
import argparse
import json
import os
from collections import defaultdict
from PIL import Image
from tqdm import tqdm   # 可去掉 tqdms 相关代码，脚本同样可运行


def load_coco(json_path):
    with open(json_path, "r", encoding="utf-8") as f:
        coco = json.load(f)

    # id → name（类别）
    cat_id2name = {c["id"]: c["name"] for c in coco.get("categories", [])}

    # image_id → image_info
    img_id2info = {im["id"]: im for im in coco["images"]}

    # image_id → [annotation, …]
    ann_by_img = defaultdict(list)
    for ann in coco["annotations"]:
        ann_by_img[ann["image_id"]].append(ann)

    return cat_id2name, img_id2info, ann_by_img


def crop_objects(img_path, img_info, anns, cat_id2name, output_root):
    """针对单张图片裁剪所有目标"""
    file_name = img_info["file_name"]
    base_name = os.path.splitext(file_name)[0]
    out_dir = os.path.join(output_root, base_name)
    os.makedirs(out_dir, exist_ok=True)

    img = Image.open(img_path)

    for ann in anns:
        x, y, w, h = ann["bbox"]        # COCO: [x_min, y_min, width, height]
        crop = img.crop((x, y, x + w, y + h))
        cat_name = cat_id2name.get(ann["category_id"], "unknown")
        out_name = f"{base_name}_ann{ann['id']}_{cat_name}.jpg"
        crop.save(os.path.join(out_dir, out_name))
    return len(anns)


def main(json_path, image_root, output_root, single_mode=False):
    cat_id2name, img_id2info, ann_by_img = load_coco(json_path)

    # 要处理的 (img_info, img_full_path) 列表
    tasks = []

    if single_mode:
        if not os.path.isfile(image_root):
            raise ValueError("--single 模式下 --image_root 必须指向图片文件")
        file_name = os.path.basename(image_root)
        # 找到 JSON 中对应的 image_info
        img_info = next(
            (im for im in img_id2info.values() if im["file_name"] == file_name),
            None,
        )
        if img_info is None:
            raise KeyError(f"{file_name} 不在 JSON 的 images 列表中")
        tasks.append((img_info, image_root))
    else:
        if not os.path.isdir(image_root):
            raise ValueError("--image_root 应该是目录，或改用 --single 模式")
        for img_info in img_id2info.values():
            img_path = os.path.join(image_root, img_info["file_name"])
            if os.path.exists(img_path):
                tasks.append((img_info, img_path))
            else:
                print(f"[警告] 找不到原图: {img_path}，已跳过")

    total_crops = 0
    for img_info, img_path in tqdm(tasks, desc="Processing images"):
        n = crop_objects(
            img_path,
            img_info,
            ann_by_img.get(img_info["id"], []),
            cat_id2name,
            output_root,
        )
        total_crops += n

    print(f"\n✔ 任务完成：共裁剪 {total_crops} 个目标，输出目录：{output_root}")


if __name__ == "__main__":
    JSON_PATH   = "/data2/vlm/wmx_code/vlm_sam2/images/cube__result.json"    # 你的 JSON 文件路径
    IMAGE_DIR   = "/data2/vlm/wmx_code/vlm_sam2/images/cube_.jpg"              # 存放原图的文件夹
    OUTPUT_DIR  = "/data2/vlm/wmx_code/vlm_sam2/images/crop_outputs"               # 裁剪结果输出目录
    parser = argparse.ArgumentParser(
        description="Crop objects from images using COCO bbox annotations"
    )
    parser.add_argument("--json_path",default = JSON_PATH,help="COCO JSON 文件路径")
    parser.add_argument(
        "--image_root",
        default = IMAGE_DIR,
        help="单张图片路径 (--single) 或 原图文件夹路径 (默认批量模式)"
    )
    parser.add_argument(
        "--output_root",
        default = OUTPUT_DIR,
        help="裁剪结果保存根目录，每张图会建子文件夹"
    )
    parser.add_argument(
        "--single",
        action="store_true",
        help="开启后把 image_root 当作单张图片处理",
    )
    args = parser.parse_args()

    main(
        json_path=args.json_path,
        image_root=args.image_root,
        output_root=args.output_root,
        single_mode=args.single,
    )
