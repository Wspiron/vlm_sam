import os
import asyncio
import sys
from pathlib import Path
CODE_SPACE=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
print(CODE_SPACE)
sys.path.append(CODE_SPACE)
os.chdir(CODE_SPACE)
from client.processor import ImageProcessor
from client.utils import log_info, log_error


SAM2_API_URL = "http://localhost:7860"
#IMAGE_DIR = "/data2/vlm/fsy_code/benchmark/outputs/blip3/image"
IMAGE_DIR = "/data2/vlm/wmx_code/vlm_sam2/images/1.jpg"
OUTPUT_DIR = "/data2/vlm/wmx_code/vlm_sam2/images"
#IMAGE_DIR = "/data2/vlm/fsy_code/benchmark/outputs/blip3/image/WKL0300015ESP02F5CB_ynyjUpgLUdqBTut4hLgPm.jpg"
#OUTPUT_DIR = "/data2/vlm/wmx_code/vlm_sam2/outputs"
USER_PROMPT = """Please detect and list all detection targets and all the people in the image in detail, output the fine-grained category(include desk) and bounding box for each object. Please output all objects in the JSON format:  ["category": category, "bbox":"x1 y1 ×2 y2"), {"category": category, "bbox": "x1 y1 x2 y2"}],please output in English"""

async def process_all_images():
    processor = ImageProcessor(SAM2_API_URL)

    # image_files = [str(p) for p in Path(IMAGE_DIR).glob("*.*") if p.suffix.lower() in [".jpg", ".png", ".jpeg"]]
    image_files = [IMAGE_DIR]
    if not image_files:
        log_error("No images found in images/ directory.")
        return

    tasks = []
    for img_path in image_files:
        log_info(f"Scheduling processing for {img_path}")
        # print(USER_PROMPT)
        tasks.append(processor.process_image(img_path, OUTPUT_DIR, USER_PROMPT))

    results = await asyncio.gather(*tasks, return_exceptions=True)  # 并发执行所有任务，异常会被捕获为结果

    for i, res in enumerate(results):
        if isinstance(res, Exception):
            log_error(f"Error processing {image_files[i]}: {res}")  # 记录具体图片的处理异常
        else:
            log_info(f"Finished processing {image_files[i]}")  # 记录成功处理的日志

if __name__ == "__main__":
    asyncio.run(process_all_images())
