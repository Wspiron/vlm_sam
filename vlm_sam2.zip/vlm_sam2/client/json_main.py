import os
import asyncio
from pathlib import Path
import json
import sys
CODE_SPACE=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
print(CODE_SPACE)
sys.path.append(CODE_SPACE)
os.chdir(CODE_SPACE)

from processor import ImageProcessor
from utils import log_info, log_error


SAM2_API_URL = "http://localhost:7860"
IMAGES_JSON = "/data2/vlm/vlm_data/pe_test.json"
OUTPUT_DIR = "/data2/vlm/wmx_code/vlm_sam2/outputs"
USER_PROMPT = """Please detect and list all detection targets and all the people in the image in detail, output the fine-grained category and bounding box for each object and people. Please output all objects and people in the JSON format:  ["category": category, "bbox":"x1 y1 ×2 y2"), {"category": category, "bbox": "x1 y1 x2 y2"}]"""

async def process_all_images():
    processor = ImageProcessor(SAM2_API_URL)

    # 1. 读取 JSON 文件
    try:
        with open(IMAGES_JSON, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception as e:
        log_error(f"Failed to load JSON file {IMAGES_JSON}: {e}")
        return

    # 2. 从 JSON 中提取所有图片路径
    image_entries = data.get("img", [])
    image_files = []
    for entry in image_entries:
        path = entry.get("path")
        if path and os.path.isfile(path):
            image_files.append(path)
        else:
            log_error(f"Invalid or missing path in JSON entry: {entry}")

    if not image_files:
        log_error("No valid images found in JSON list.")
        return


    tasks = []
    for img_path in image_files:
        log_info(f"Scheduling processing for {img_path}")
        # print(USER_PROMPT)
        tasks.append(processor.process_image(img_path, OUTPUT_DIR, USER_PROMPT))

    results = await asyncio.gather(*tasks, return_exceptions=True)  # 并发执行所有任务，异常会被捕获为结果

    for i, res in enumerate(results):
        if isinstance(res, Exception):
            log_error(f"Error processing {image_files[i]}: {res}")  # 记录具体图片的处理异常
        else:
            log_info(f"Finished processing {image_files[i]}")  # 记录成功处理的日志

if __name__ == "__main__":
    asyncio.run(process_all_images())
