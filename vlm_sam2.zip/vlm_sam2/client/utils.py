import os
import json
import base64
from PIL import Image
from io import BytesIO

def save_mask_json(output_dir: str, base_name: str, data: dict):
    os.makedirs(output_dir, exist_ok=True)
    json_path = os.path.join(output_dir, f"{base_name}_segmentation.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def save_segmentation_mask(output_dir: str, base_name: str, mask_base64: str):
    if not mask_base64:
        print(f"[WARN] No mask data for {base_name}")
        return

    os.makedirs(output_dir, exist_ok=True)
    mask_bytes = base64.b64decode(mask_base64)
    image = Image.open(BytesIO(mask_bytes))
    mask_path = os.path.join(output_dir, f"{base_name}_mask.png")
    image.save(mask_path)
    print(f"[INFO] Saved segmentation mask to {mask_path}")

def log_info(msg: str):
    print(f"[INFO] {msg}")

def log_error(msg: str):
    print(f"[ERROR] {msg}")
