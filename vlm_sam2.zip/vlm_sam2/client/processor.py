import os
import json
import asyncio
import aiohttp
from typing import Dict, Any

from vlm_infer.vlm_client import VLMClient
from utils import save_mask_json, save_segmentation_mask

class ImageProcessor:
    def __init__(self, sam2_api_url: str):
        self.sam2_api_url = sam2_api_url
        self.vlm_client = VLMClient()

    async def call_sam2(self, image_path: str, points: list, bboxes: list, class_ids: list) -> Dict[str, Any]:
        payload = {
            "image_path":image_path,
            "points": points,
            "bboxes": bboxes,
            "class_ids": class_ids
        }
        print(payload)
        async with aiohttp.ClientSession() as session:
            async with session.post(self.sam2_api_url + "/segment", json=payload, timeout=60) as resp:
                resp.raise_for_status()
                result = await resp.json()
                return result

    async def process_image(self, image_path: str, output_dir: str, user_prompt: str):
        vlm_result = self.vlm_client.get_points_and_bboxes(image_path, user_prompt)
        points = vlm_result.get("points", [])
        bboxes = vlm_result.get("bboxes", [])
        class_ids = vlm_result.get("class_ids", [])
        sam_result = await self.call_sam2(image_path, points, bboxes, class_ids)