import os
import base64
from openai import OpenAI 
from PIL import Image
import json

class VLMClient:
    def __init__(self, api_key: str = None, base_url: str = None, model_version: str = None):
        os.environ['OPENAI_API_KEY'] = '2dcea885-6458-40a8-85e0-41e706bf2c47'
        self.api_key = os.environ.get("OPENAI_API_KEY")
        self.base_url = base_url or "https://ark.cn-beijing.volces.com/api/v3"
        self.model_version = model_version or "ep-20250527113039-bdkdv"
        
        
        self.client = OpenAI(base_url=self.base_url, api_key=self.api_key)

    def encode_image(self, image_path: str) -> str:
        with open(image_path, "rb") as image_file:
            encoded = base64.b64encode(image_file.read()).decode('utf-8')
        return encoded

    def inference_image(self,image_path: str,prompt: str) -> str:
        base64_image = self.encode_image(image_path)
        image_format = image_path.split('.')[-1].lower()
        assert image_format in ['jpg', 'jpeg', 'png', 'webp'], f"Unsupported image format: {image_format}"

        messages = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/{image_format};base64,{base64_image}"
                        },
                    },
                    {"type": "text", "text": prompt},
                ],
            }
        ]

        response = self.client.chat.completions.create(
            model=self.model_version,
            messages=messages,
        )
        return response.choices[0].message.content

    def transfer_bbox(self,result,img_height,img_width):
        bbox_infos = json.loads(result)
        # print(bbox_infos)
        bboxes = []
        points = []
        class_ids = []
        for bbox_info in bbox_infos:
            class_id = bbox_info["category"]
            bbox = bbox_info["bbox"]
            bbox = list(map(int, bbox.split()))
            bbox[0] = int(bbox[0]/1000*img_width)
            bbox[1] = int(bbox[1]/1000*img_height)
            bbox[2] = int(bbox[2]/1000*img_width)
            bbox[3] = int(bbox[3]/1000*img_height)
            point = [(bbox[0]+bbox[2])//2,(bbox[1]+bbox[3])//2]
            bboxes.append(bbox)
            points.append(point)
            class_ids.append(class_id)
        return bboxes,points,class_ids




    def get_points_and_bboxes(self, image_path,user_prompt):
        # print("1111",image_path,user_prompt)
        result = self.inference_image(image_path, user_prompt)
#         result = """[
# {"category": "person", "bbox": "224 139 270 330"},
# {"category": "person", "bbox": "279 72 314 260"},
# {"category": "person", "bbox": "297 144 320 255"},
# {"category": "person", "bbox": "330 266 412 657"},
# {"category": "person", "bbox": "231 401 300 553"},
# {"category": "person", "bbox": "500 22 534 148"},
# {"category": "person", "bbox": "584 54 617 221"},
# {"category": "person", "bbox": "713 75 737 197"},
# {"category": "person", "bbox": "458 22 472 66"},
# {"category": "person", "bbox": "537 13 554 115"},
# {"category": "person", "bbox": "575 14 590 115"},
# {"category": "person", "bbox": "631 13 644 54"},
# {"category": "person", "bbox": "652 13 663 54"}
# ]"""
        print(result)
        image = Image.open(image_path).convert("RGB")
        img_height, img_width = image.height, image.width


        bboxes,points,class_ids = self.transfer_bbox(result,img_height,img_width)
        print(bboxes,points,class_ids)

        return {
            "points": points,
            "bboxes": bboxes,
            "class_ids": class_ids
        }



if __name__ == "__main__":
    vlm = VLMClient(api_key="xxxx")
    prompt = "Please detect objects with bboxes, points, and class_ids."
    image_path = "./images/example.jpg"
    result = vlm.inference_image(prompt, image_path)
    print("VLM Inference Result:", result)
